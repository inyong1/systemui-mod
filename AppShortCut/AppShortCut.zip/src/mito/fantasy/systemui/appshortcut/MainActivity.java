package mito.fantasy.systemui.appshortcut;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.preference.*;

public class MainActivity extends Activity
{
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
		{
        super.onCreate(savedInstanceState);
      /*  new Handler().postDelayed(new Runnable(){

                @Override
                public void run()
                {
                    */
                    setContentView(R.layout.main);
                    getFragmentManager().beginTransaction().replace(android.R.id.content,new ShortCutPreference()).commit();
                    PreferenceManager.setDefaultValues(this, R.xml.preferences, false);
                    
        //        }
           // }, 100);
        
				   }
}
