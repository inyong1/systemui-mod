package mito.fantasy.systemui.appshortcut;

import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.os.*;
import android.preference.*;
import android.provider.*;
import android.widget.*;
import java.util.*;
import mito.fantasy.systemui.appshortcut.inyong.*;
import android.graphics.drawable.*;

public class ShortCutPreference extends PreferenceFragment implements Preference.OnPreferenceClickListener
{

		private ContentResolver contentResolver;
		private final Intent intent=new Intent("inyong.appshortcutview");
		private Preference 
		prefEnableDisable,
		prefTambahShortcut,
    prefDeletShorcut;
		private SharedPreferences 	sharedPref;

    private PackageManager packageManager;
  //  private ArrayList<DetilItemApp> listAppTemp;
    private ArrayList<DetilItemApp> listAppUrut;
    //   private ArrayList<DetilItemApp> listAppfinal;
    //  private ArrayList<DetilItemApp> listAppPadaShortcut;
    AdapterListAplikasi adapterListAplikasi;
    private Thread threadPekerja;
    private boolean prosesDibelakang;



		public void onCreate(Bundle b)
		{

				super.onCreate(b);
				addPreferencesFromResource(R.xml.preferences);
				contentResolver = getActivity().getContentResolver();
        packageManager = getActivity().getPackageManager();

   //     listAppTemp = new ArrayList<DetilItemApp>();
        listAppUrut = new ArrayList<DetilItemApp>();
        // listAppfinal=new ArrayList<DetilItemApp>();

        //  listAppPadaShortcut=new ArrayList<DetilItemApp>();

        buatListDibelakang();
				sharedPref = getPreferenceScreen().getSharedPreferences();
				prefEnableDisable = findPreference(ShortCutListView.NAMA_SETING_SHORTCUT_AKTIF);
				prefEnableDisable.setOnPreferenceClickListener(this);
				prefTambahShortcut = findPreference("tambah_shortcut");
				prefTambahShortcut.setOnPreferenceClickListener(this);
        prefDeletShorcut = findPreference("hapus_shortcut");
        prefDeletShorcut.setOnPreferenceClickListener(this);
		}


		public boolean onPreferenceClick(Preference pref)
		{
				if (pref.equals(prefEnableDisable))
				{
						boolean aktif=sharedPref.getBoolean(ShortCutListView.NAMA_SETING_SHORTCUT_AKTIF, true);	
						Settings.System.putInt(contentResolver, ShortCutListView.NAMA_SETING_SHORTCUT_AKTIF, aktif ? 1: 0);
				}
        else if (pref.equals(prefTambahShortcut))
        {
            if (prosesDibelakang)
            {
                tampilkanHarapTunggu();
            }
            else
            {
                tampilkanDialogTambahShortcut();
            }

				}
        else if (pref.equals(prefDeletShorcut))
        {
            tampilkanDialogHapusShortcut();
        }
				getActivity().sendBroadcast(intent);
				return true;
		}

    private void tampilkanHarapTunggu()
    {
        final ProgressDialog progressDialog=ProgressDialog.show (getActivity(), null, getActivity().getResources().getString(R.string.membuat_list_app));
        final Handler handler = new Handler();
        new Thread(new Runnable(){

                @Override
                public void run()
                {
                    while (prosesDibelakang)
                    {
                        try
                        {
                            Thread.sleep(500);
                        }
                        catch (InterruptedException e)
                        {}
                    }
                    handler.post(new Runnable(){

                            @Override
                            public void run()
                            {
                                progressDialog.dismiss();
                                tampilkanDialogTambahShortcut();
                            }
                        });

                }
            }).start();

    }

    private void tampilkanDialogTambahShortcut()
    {
        AlertDialog.Builder dialog=new AlertDialog.Builder(getActivity());
        dialog.setTitle(getActivity().getResources().getString(R.string.pilih_aplikasi_tambah_shortcut));
        dialog.setAdapter(adapterListAplikasi, new Dialog.OnClickListener(){

                @Override
                public void onClick(DialogInterface p1, int posisi)
                {
                    tambahShorcut(listAppUrut.get(posisi).getNamaPackageAplikasi());
                }
            });
        dialog.show();
    }

    private void tambahShorcut(String namaPackage)
    {

        String tersimpan=Settings.System.getString(contentResolver, ShortCutListView.NAMA_SETING_PACKAGE_STRING);
        Settings.System.putString(contentResolver, ShortCutListView.NAMA_SETING_PACKAGE_STRING, String.valueOf(tersimpan + namaPackage + " "));
        // Toast.makeText(getActivity(),String.valueOf( tersimpan+namaPackage+" "),2000).show();

        getActivity().sendBroadcast(intent);
    }
    private void  tampilkanDialogHapusShortcut()
    {
        String tersimpan=Settings.System.getString(contentResolver, ShortCutListView.NAMA_SETING_PACKAGE_STRING);
        final String[] tersimpanArray=tersimpan.split(" ");
        if (tersimpanArray.length < 1)return;
        ArrayList<Ikon> listIkon=new ArrayList<Ikon>();
        Ikon ikon;
        for (String namaPackage:tersimpanArray)
        {
            ikon = new Ikon();
            Drawable d=null;
            try
            {
                d = packageManager.getApplicationIcon(namaPackage);
            }
            catch (Exception e)
            {}
            ikon.setIkon(d);
            listIkon.add(ikon);
        }
        AlertDialog.Builder dialog=new AlertDialog.Builder(getActivity());
        dialog.setTitle(getActivity().getResources().getString(R.string.title_dialog_hapus_shortcut));

        dialog.setAdapter(new IkonAdapter(getActivity(), listIkon), new DialogInterface.OnClickListener(){

                @Override
                public void onClick(DialogInterface p1, int posisi)
                {
                    String setelahDihapus="";
                    for (int i=0;i < tersimpanArray.length;i++)
                    {
                        if (i == posisi)
                        {
                            continue;
                        }
                        else
                        {
                            setelahDihapus += tersimpanArray[i] + " ";
                        }
                    }
                    Settings.System.putString(contentResolver, ShortCutListView.NAMA_SETING_PACKAGE_STRING, setelahDihapus);
                    getActivity().sendBroadcast(intent);
                    if (setelahDihapus.equals("") || !setelahDihapus.contains(" "))tampilkanDialogAutoDefault();
                }
            });


        dialog.show();
    }
    private void tampilkanDialogAutoDefault()
    {
        AlertDialog.Builder dialog=new AlertDialog.Builder(getActivity());
        dialog.setTitle(getActivity().getResources().getString(R.string.title_dialog_auto_default_shortcut));
        dialog.setMessage(getActivity().getResources().getString(R.string.pesan_dialog_auto_default_shortcut));
        dialog.setPositiveButton("OK", new DialogInterface.OnClickListener(){

                @Override
                public void onClick(DialogInterface p1, int p2)
                {
                    p1.dismiss();
                }
            });
        dialog.show();
    }
    private void buatListDibelakang()
    {
        prosesDibelakang = true;
        threadPekerja = new Thread(new Runnable(){
                @Override
                public void run()
                {
                    adapterListAplikasi = new AdapterListAplikasi(getActivity(), listAppUrut);
                    Intent intent = new Intent(Intent.ACTION_MAIN, null);
                    intent.addCategory(Intent.CATEGORY_LAUNCHER);
                    List<ResolveInfo> listResolveInfo = packageManager.queryIntentActivities(intent, PackageManager.GET_META_DATA);
                    ArrayList<String> listStringApkPlusNamaPackage=new ArrayList<String>();
                    String string="";
                    for (ResolveInfo resolveInfo:listResolveInfo)
                    {
                        string = resolveInfo.loadLabel(packageManager).toString() + " " + resolveInfo.activityInfo.packageName;
                        listStringApkPlusNamaPackage.add(string);
                    }
                    
                    Collections.sort(listStringApkPlusNamaPackage ,new PembandingIgnoreCase());
                    String[] arrayStringTerpisah;
                    Drawable ikon=null;
                    DetilItemApp detilApp;
                    listAppUrut.clear();
                    for(String stringGabungan:listStringApkPlusNamaPackage){
                        arrayStringTerpisah=stringGabungan.split(" ");
                        try{
                            ikon=packageManager.getApplicationIcon(arrayStringTerpisah[1]);
                            detilApp=new DetilItemApp();
                            detilApp.setIkon(ikon);
                            detilApp.setNamaAplikasi(arrayStringTerpisah[0]);
                            detilApp.setNamaPackageAplikasi(arrayStringTerpisah[1]);
                            listAppUrut.add(detilApp);
                        }catch(Exception e){}
                    }
                    
                    /* listAppTemp.clear();
                     DetilItemApp detilItemApp=null;
                     for (ResolveInfo resolveInfo:listResolveInfo)
                     {
                     detilItemApp = new DetilItemApp();
                     detilItemApp.setNamaAplikasi(resolveInfo.loadLabel(packageManager).toString());
                     detilItemApp.setNamaPackageAplikasi(resolveInfo.activityInfo.packageName);
                     detilItemApp.setIkon(resolveInfo.loadIcon(packageManager));
                     listAppTemp.add(detilItemApp);

                     }
                     */
                     listResolveInfo = null;
                     listStringApkPlusNamaPackage=null;
                    // listAppUrut.clear();
                    // listAppUrut.addAll(listAppTemp);
                     prosesDibelakang = false;
                    // listAppTemp.clear();

                     

                }
            });   
        threadPekerja.start();   
    }

    private class PembandingIgnoreCase implements Comparator<String>
    {
        public int compare(String strA, String strB)
        {
            return strA.compareToIgnoreCase(strB);
        }
    }
}
