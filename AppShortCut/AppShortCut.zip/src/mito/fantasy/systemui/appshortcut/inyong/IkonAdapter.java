package mito.fantasy.systemui.appshortcut.inyong;

import android.content.*;
import android.view.*;
import android.widget.*;
import java.util.*;
import mito.fantasy.systemui.appshortcut.*;

public class IkonAdapter extends BaseAdapter
{
		private Context context;
		private List<Ikon> listIkon;
    private LayoutInflater layoutInflater;

		public IkonAdapter(Context context, ArrayList<Ikon> listIkon)
		{
				this.context = context;
				this.listIkon = listIkon;
        layoutInflater=LayoutInflater.from(context);
		}

		public int getCount()
		{
				// TODO: Implement this method
				return listIkon.size();
		}

		public Object getItem(int p1)
		{
				// TODO: Implement this method
				return listIkon.get(p1);
		}

		public long getItemId(int p1)
		{
				// TODO: Implement this method
				return p1;
		}
//-------
		private static class PenampungView
		{
				ImageView imageView;
		}
		
		public View getView(int posisi, View view, ViewGroup p3)
		{
				PenampungView penampung;

				if (view == null)
				{
						penampung=new PenampungView();

					//	view = new ImageView(context);
          view=layoutInflater.inflate(R.layout.ikon_shortcut,null);
					//	view.setLayoutParams(new ViewGroup.LayoutParams(100,300));
						
						penampung.imageView= (ImageView) view;
						penampung.imageView.setPadding(10, 10, 10, 20);
						
						view.setTag(penampung);
				}
				else
				{
						penampung = (PenampungView) view.getTag();
				}
				penampung.imageView.setImageDrawable(listIkon.get(posisi).getIkon());

				return view;
		}

}
